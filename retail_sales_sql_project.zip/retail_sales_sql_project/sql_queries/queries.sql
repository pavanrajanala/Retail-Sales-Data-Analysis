-- Create Table
CREATE TABLE retail_sales (
    OrderID INT,
    CustomerName VARCHAR(50),
    Product VARCHAR(50),
    Category VARCHAR(50),
    Quantity INT,
    Price INT,
    OrderDate DATE
);

-- Total Revenue
SELECT SUM(Quantity * Price) AS TotalRevenue
FROM retail_sales;

-- Top Selling Products
SELECT Product, SUM(Quantity) AS TotalSold
FROM retail_sales
GROUP BY Product
ORDER BY TotalSold DESC;

-- Monthly Sales Trend
SELECT MONTH(OrderDate) AS Month,
       SUM(Quantity * Price) AS MonthlyRevenue
FROM retail_sales
GROUP BY MONTH(OrderDate)
ORDER BY Month;

-- Category-wise Revenue
SELECT Category,
       SUM(Quantity * Price) AS Revenue
FROM retail_sales
GROUP BY Category;

-- Customer Purchase Behavior
SELECT CustomerName,
       COUNT(OrderID) AS TotalOrders,
       SUM(Quantity * Price) AS TotalSpent
FROM retail_sales
GROUP BY CustomerName
ORDER BY TotalSpent DESC;

-- Average Order Value
SELECT AVG(Quantity * Price) AS AvgOrderValue
FROM retail_sales;
