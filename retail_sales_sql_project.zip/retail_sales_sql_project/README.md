# Retail Sales Data Analysis using SQL

## Project Overview
This project analyzes retail sales data using SQL to extract meaningful business insights.  
The project demonstrates SQL skills such as data cleaning, aggregation, joins, grouping, and trend analysis.

## Objectives
- Analyze sales performance
- Identify top-selling products
- Track monthly sales trends
- Understand customer purchase behavior
- Generate business reports

## Tools Used
- SQL
- MySQL / PostgreSQL / SQLite
- CSV Dataset

## Key SQL Concepts
- SELECT Statements
- WHERE Clause
- GROUP BY
- ORDER BY
- Aggregate Functions
- JOIN Operations
- Subqueries

## Project Structure
- `dataset/retail_sales.csv` → Sample dataset
- `sql_queries/queries.sql` → SQL analysis queries
- `reports/insights.txt` → Business insights

## Sample Insights
- Electronics category generated the highest revenue.
- Monthly sales increased during festive seasons.
- Repeat customers contributed significantly to total sales.

## Author
Sanjay
